package org.lunifera.entitydsl.samples.sample05;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Table;
import org.lunifera.entitydsl.samples.sample05.Item;

@Entity
@Table(name = "ARTICLE")
@SuppressWarnings("all")
public class Article extends Item {
  @ElementCollection
  @Column(name = "DESCRIPTION")
  private List<String> description;
  
  @Column(name = "PRICE")
  private int price;
  
  /**
   * Checks whether the object is disposed.
   * @throws RuntimeException if the object is disposed.
   */
  private void checkDisposed() {
    if (isDisposed()) {
      throw new RuntimeException("Object already disposed: " + this);
    }
  }
  
  /**
   * Calling dispose will destroy that instance. The internal state will be 
   * set to 'disposed' and methods of that object must not be used anymore. 
   * Each call will result in runtime exceptions.<br/>
   * If this object keeps composition containments, these will be disposed too. 
   * So the whole composition containment tree will be disposed on calling this method.
   */
  public void dispose() {
    if (isDisposed()) {
      return;
    }
    super.dispose();
  }
  
  /**
   * Returns an unmodifiable list of description.
   */
  public List<String> getDescription() {
    checkDisposed();
    return Collections.unmodifiableList(internalGetDescription());
  }
  
  /**
   * Returns the list of <code>String</code>s thereby lazy initializing it.
   */
  private List<String> internalGetDescription() {
    if (this.description == null) {
      this.description = new ArrayList<String>();
    }
    return this.description;
  }
  
  /**
   * Adds the given string to this object. <p>
   * ATTENTION:<br>
   * The reference is a composition reference, but no opposite is available.
   * So the opposite will NOT be handled. Therefore you have to ensure that the parent of the reference
   * is set properly.
   * 
   */
  public void addToDescription(final String string) {
    checkDisposed();
    if (!internalGetDescription().contains(string)){
      internalGetDescription().add(string);
    }
    
  }
  
  public void removeFromDescription(final String string) {
    checkDisposed();
    getDescription().remove(string);
  }
  
  /**
   * Returns the price property or <code>null</code> if not present.
   */
  public int getPrice() {
    checkDisposed();
    return this.price;
  }
  
  /**
   * Sets the price property to this instance.
   */
  public void setPrice(final int price) {
    checkDisposed();
    this.price = price;
  }
}
