package org.lunifera.entitydsl.samples.sample01;

@SuppressWarnings("all")
public enum MyEnum {
}
