package org.lunifera.entitydsl.samples.sample06;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import org.lunifera.entitydsl.samples.sample06.Vehicle;

@Entity
@DiscriminatorValue(value = "BIKE")
@SuppressWarnings("all")
public class Bike extends Vehicle {
  @ElementCollection
  @Column(name = "BIKEDESCRIPTION")
  private List<String> bikedescription;
  
  @Column(name = "PRICE")
  private int price;
  
  /**
   * Checks whether the object is disposed.
   * @throws RuntimeException if the object is disposed.
   */
  private void checkDisposed() {
    if (isDisposed()) {
      throw new RuntimeException("Object already disposed: " + this);
    }
  }
  
  /**
   * Calling dispose will destroy that instance. The internal state will be 
   * set to 'disposed' and methods of that object must not be used anymore. 
   * Each call will result in runtime exceptions.<br/>
   * If this object keeps composition containments, these will be disposed too. 
   * So the whole composition containment tree will be disposed on calling this method.
   */
  public void dispose() {
    if (isDisposed()) {
      return;
    }
    super.dispose();
  }
  
  /**
   * Returns an unmodifiable list of bikedescription.
   */
  public List<String> getBikedescription() {
    checkDisposed();
    return Collections.unmodifiableList(internalGetBikedescription());
  }
  
  /**
   * Returns the list of <code>String</code>s thereby lazy initializing it.
   */
  private List<String> internalGetBikedescription() {
    if (this.bikedescription == null) {
      this.bikedescription = new ArrayList<String>();
    }
    return this.bikedescription;
  }
  
  /**
   * Adds the given string to this object. <p>
   * ATTENTION:<br>
   * The reference is a composition reference, but no opposite is available.
   * So the opposite will NOT be handled. Therefore you have to ensure that the parent of the reference
   * is set properly.
   * 
   */
  public void addToBikedescription(final String string) {
    checkDisposed();
    if (!internalGetBikedescription().contains(string)){
      internalGetBikedescription().add(string);
    }
    
  }
  
  public void removeFromBikedescription(final String string) {
    checkDisposed();
    getBikedescription().remove(string);
  }
  
  /**
   * Returns the price property or <code>null</code> if not present.
   */
  public int getPrice() {
    checkDisposed();
    return this.price;
  }
  
  /**
   * Sets the price property to this instance.
   */
  public void setPrice(final int price) {
    checkDisposed();
    this.price = price;
  }
}
