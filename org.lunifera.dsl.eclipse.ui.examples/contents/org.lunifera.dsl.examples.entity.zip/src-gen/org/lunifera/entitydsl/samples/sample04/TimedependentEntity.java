package org.lunifera.entitydsl.samples.sample04;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "TIMEDEPENDENT_ENTITY")
@DiscriminatorValue(value = "TIMEDEPENDENT_ENTITY")
@SuppressWarnings("all")
public class TimedependentEntity {
  @Transient
  private boolean disposed;
  
  @Id
  private String id = java.util.UUID.randomUUID().toString();
  
  @Column(name = "OBJ_ID")
  private String objId = java.util.UUID.randomUUID().toString();
  
  @Column(name = "VALID_FROM")
  @Temporal(value = TemporalType.DATE)
  private Date validFrom;
  
  @Column(name = "VALID_UNTIL")
  @Temporal(value = TemporalType.DATE)
  private Date validUntil;
  
  /**
   * Returns true, if the object is disposed. 
   * Disposed means, that it is prepared for garbage collection and may not be used anymore. 
   * Accessing objects that are already disposed will cause runtime exceptions.
   */
  public boolean isDisposed() {
    return this.disposed;
  }
  
  /**
   * Checks whether the object is disposed.
   * @throws RuntimeException if the object is disposed.
   */
  private void checkDisposed() {
    if (isDisposed()) {
      throw new RuntimeException("Object already disposed: " + this);
    }
  }
  
  /**
   * Calling dispose will destroy that instance. The internal state will be 
   * set to 'disposed' and methods of that object must not be used anymore. 
   * Each call will result in runtime exceptions.<br/>
   * If this object keeps composition containments, these will be disposed too. 
   * So the whole composition containment tree will be disposed on calling this method.
   */
  public void dispose() {
    if (isDisposed()) {
      return;
    }
    disposed = true;
  }
  
  /**
   * Returns the id property or <code>null</code> if not present.
   */
  public String getId() {
    checkDisposed();
    return this.id;
  }
  
  /**
   * Sets the id property to this instance.
   */
  public void setId(final String id) {
    checkDisposed();
    this.id = id;
  }
  
  /**
   * Returns the objId property or <code>null</code> if not present.
   */
  public String getObjId() {
    checkDisposed();
    return this.objId;
  }
  
  /**
   * Sets the objId property to this instance.
   */
  public void setObjId(final String objId) {
    checkDisposed();
    this.objId = objId;
  }
  
  /**
   * Returns the validFrom property or <code>null</code> if not present.
   */
  public Date getValidFrom() {
    checkDisposed();
    return this.validFrom;
  }
  
  /**
   * Sets the validFrom property to this instance.
   */
  public void setValidFrom(final Date validFrom) {
    checkDisposed();
    this.validFrom = validFrom;
  }
  
  /**
   * Returns the validUntil property or <code>null</code> if not present.
   */
  public Date getValidUntil() {
    checkDisposed();
    return this.validUntil;
  }
  
  /**
   * Sets the validUntil property to this instance.
   */
  public void setValidUntil(final Date validUntil) {
    checkDisposed();
    this.validUntil = validUntil;
  }
}
